//
// Created by RM UI Designer
//

#ifndef UI_default_Ungroup_0_H
#define UI_default_Ungroup_0_H

#include "ui_interface.h"

extern ui_interface_string_t *ui_default_Ungroup_shoot;

void _ui_init_default_Ungroup_0();
void _ui_update_default_Ungroup_0();
void _ui_remove_default_Ungroup_0();

#endif //UI_default_Ungroup_0_H
